"""Rescore the two preserved native POD fields from the approved original opening, on cluster."""
import hashlib
import json
import os
from pathlib import Path
import sys

import numpy as np

ROOT = Path("/cluster/tufts/paralab/tawal01")
COLD = ROOT / "burgers-archive/jcp-sealed-closeout-20261115"
FROZEN = "659009ee48e40bfe5d57e176b8c08ad9a24840f0f342c5b48ea9aef5c3babd41"
APPROVED = "898f19eb1c1c0753656121f6a7d0b4ac70a77f44f539718234abf8631bf9652c"
PUBLICATION = "cf22a18268c15f44d3eab6b7193b90553248747b88778b68ab3e429ae5af8d71"
STORE = "3ec3b5492748a162c9d77e7c09cdbe1485d449a31bd73a29175b4a0e4efc66a0"
JOB = {2:"7244116", 3:"7244115"}


def digest(path):
    with path.open("rb") as src:
        return hashlib.file_digest(src, "sha256").hexdigest()


def verify(condition, label):
    if not condition:
        raise ValueError(label)


def rescore(field, truth, n0):
    # Separate implementation. Accumulate squared element differences and norms in extended precision.
    verify(field.shape == truth.shape and field.shape[0] == 6, "incorrect scoring lattice")
    verify(field.dtype == truth.dtype == np.float64 and np.all(np.isfinite(field)) and np.all(np.isfinite(truth)), "invalid fields")
    verify(np.isfinite(n0) and n0 > 0., "invalid original norm")
    values = []
    for k in range(1, 6):
        delta = np.subtract(field[k], truth[k], dtype=np.longdouble)
        norm_sq = np.sum(np.multiply(delta, delta), dtype=np.longdouble)
        values.append(float(np.sqrt(norm_sq) / np.longdouble(n0)))
    return values


def main(d):
    job = JOB[d]
    cold = COLD / f"pod{d}"
    out = cold / "output"
    src = cold / "experiments/jcp-sealed-closeout"
    verify(digest(src/"F1.json") == FROZEN and digest(src/"F1-REVIEW.json")==APPROVED, "incorrect study admission")
    freeze = json.loads((src/"F1.json").read_bytes())
    for file in ("open_sealed.py", "published.py", "witness_audit.py", f"configs/pod{d}.json"):
        verify(digest(src/file)==freeze["files"][file], f"unauthenticated source {file}")
    sys.path.insert(0, str(src))
    from published import Opened
    from witness_audit import TOL
    cfg_file = src / f"configs/pod{d}.json"
    opened = Opened(src,cfg_file)
    completion = json.loads((opened.registry/"COMPLETE.json").read_bytes())
    verify(completion["published_sha256"]==PUBLICATION and completion["freeze_sha256"]==FROZEN and completion["store_version"]==STORE, "different original publication")
    scores_by_case = [json.loads(line) for line in (out/"result.jsonl").read_bytes().splitlines()]
    rows = {(r["case"],r["rep"]):r for r in scores_by_case}
    co = {2:"sealed128",3:"sealed64"}[d]
    expected_rows = {(i,r) for i in range({2:128,3:64}[d]) for r in range(5 if i<6 else 1)}
    verify(len(rows)==len(scores_by_case) and set(rows)==expected_rows,"incomplete run records")
    meta = json.loads((out/"COMPLETE.json").read_bytes())
    verify(meta["job_id"]==job and meta["x64"] and meta["precision"]=="highest" and meta["backend"]=="gpu","incorrect production run")
    st = ROOT / "jcp-sealed-closeout-20261115/base/experiments/burgers-quadrature-plateau/vendor/tree/experiments/jcp-references/store/STATUS.json"
    verify(digest(st)==opened.status_sha,"wrong dimension status")
    dim_valid = json.loads(st.read_bytes())["dimension_status"][str(d)]=="validated"
    receipt = dict(production_job=job, audit_job=os.environ["SLURM_JOB_ID"], native_subject=meta["subject"],
        cohort=co, field_dtype="float64", accumulation_mantissa_bits=int(np.finfo(np.longdouble).nmant),
        freeze_sha256=FROZEN, review_sha256=APPROVED, publication_sha256=PUBLICATION, store_sha256=STORE,
        result_sha256=digest(out/"result.jsonl"), input_inventory_sha256=digest(cold/"OUTPUTS.sha256"),
        archive_manifest_sha256=digest(cold/"ARCHIVE.sha256"), independent_script_sha256=digest(Path(__file__)),
        production_source_commit=meta["source_commit"], check="rescore 2 saved cases, 2 reference kinds, 5 post-initial frames (rep 0)", cases=[])
    for i in (0,2):
        row=rows[i,0]
        path=out/f"case{i:03d}.npz"
        verify(row["subject"]==meta["subject"] and row["finite"],"misidentified saved field")
        with np.load(path,allow_pickle=False) as z:
            fields=z["fields"]
        case=dict(case=i, repetition=0, witness_sha256=digest(path), kinds={})
        for k in ("ST","S"):
            truth, reference=opened.load(d,co,i,k)
            score=rescore(fields,truth,reference["judge"]["n0"])
            orig=row[k]
            verify(orig["eligible"] == (reference["outcome"]=="accepted" and dim_valid)
                   and orig["outcome"] == reference["outcome"] and orig["eps_ref"] == reference["judge"]["eps_ref"],"eligibility or uncertainty mismatch")
            differences=np.abs(np.asarray([max(score),*score])-np.asarray([orig["e"],*orig["et"]]))
            verify(len(differences)==6 and np.isfinite(differences).all(), "invalid saved scores")
            rel=float(differences.max()/max(max(score),1e-300))
            case["kinds"][k]=dict(eligible=orig["eligible"],outcome=orig["outcome"],
                rescored_trajectory_max=max(score),stored_trajectory_max=orig["e"],
                rescored_per_frame=score,stored_per_frame=orig["et"],max_abs_difference=float(differences.max()),
                max_difference_relative_to_trajectory=rel,within_existing_witness_tolerance=rel<=TOL)
        receipt["cases"].append(case)
    checks=[v for c in receipt["cases"] for v in c["kinds"].values()]
    receipt.update(original_witness_comparison_tolerance=TOL,
                   max_abs_difference=max(v["max_abs_difference"] for v in checks),
                   max_difference_relative_to_trajectory=max(v["max_difference_relative_to_trajectory"] for v in checks),
                   agreement=all(v["within_existing_witness_tolerance"] for v in checks))
    Path("receipt.json").write_text(json.dumps(receipt,indent=2,sort_keys=True,allow_nan=False)+"\n")
    print("POD witness", d, "agreement",receipt["agreement"],"max relative discrepancy",receipt["max_difference_relative_to_trajectory"],flush=True)


if __name__=="__main__":
    main(int(sys.argv[1]))
