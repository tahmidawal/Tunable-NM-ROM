# Recorded multiresolution experiment results

This bundle contains provisional development results for the current separable NM-ROM campaign. Numerical results were finalized on the date in the canonical report filename; later packaging does not represent new experiments.

Open `reports/2026-09-07-multiresolution-pilots.md` for the experiment-level findings and linked plots. The experiment index lists all 17 completed GPU studies, with source revisions and exact result-file hashes. The 52 source JSON artifacts retain raw timing repetitions, physical errors, configurations, audits and diagnostic records in their native schemas. The absorbing-wave moment analysis is included as saved-run postprocessing, not another GPU study.

The original ViT + CP comparison and reset older-wave evidence are outside this campaign. Proposed Jacobian reuse, shared wave derivative calculations and new learned predictors have no new results in this bundle. No nonlinear-ROM complete-query advantage over the tested efficient FOMs is established. Error norms and cohorts differ across PDEs, and independent final confirmation remains unopened.

Full field arrays, trained checkpoints, staged source trees and cluster logs remain in the separately tracked experiment archives. This bundle is a results export, not a standalone reproduction environment. Relative links to those omitted artifacts and original absolute provenance paths still require the project workspace. `BUNDLE-MANIFEST.json` gives checksums for every included report, source JSON, index, figure and exporter script.

Timing arrays inside different result schemas have different roles: repeated comparisons, separate accuracy controls, warmups and component diagnostics must not be pooled as equivalent measurements. The source records retain those roles. Stored row counts are not necessarily invocation counts.

## Plain-language glossary

- **PDE / experiment / result_json:** partial differential equation / the numerical question tested / the path to its original machine-readable result file.
- **GPU study / job ID:** one recorded cluster experiment / its scheduler identifier.
- **Source revision / SHA256:** the exact saved code version / a fingerprint of file contents.
- **ROM / FOM:** reduced mathematical model / full spatial solver.
- **NM-ROM:** a reduced model whose solution is constrained by a nonlinear decoder.
- **Query:** supplied input field through the requested returned solution fields.
- **Development / final confirmation:** inputs used while improving the method / independent inputs reserved for the final test.
- **Checkpoint / field array:** trained network weights / numerical solution values on a grid.
- **Timing repetition / accuracy control / warmup:** repeated measurement / separate check of numerical accuracy / preparation before comparable timing.
- **Native schema / provenance:** an experiment's original record format / the history identifying how a result was produced.
