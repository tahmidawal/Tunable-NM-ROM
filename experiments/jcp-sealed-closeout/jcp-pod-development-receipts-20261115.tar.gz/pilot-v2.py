"""Development-only comparability witness. The process has no opening code."""
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np

from jcp_frozen_classical_pod import prepare

base = Path(__file__).resolve().parent
dim = int(sys.argv[1])
archive = Path("/cluster/tufts/paralab/tawal01/burgers-archive")
assets = {
    2: archive / "imp-multimesh/j0/output/src256",
    3: archive / "jcp-hr-baselines/t3d64b/jobdir/output/artifacts/Phi.npz",
}
name, ic, invoke = prepare(dim, base / "experiments", assets[dim])
import hrcore as h
import jax

if dim == 2:
    desc = h.Family(2, "dev6").D
    with np.load(archive / "imp-multimesh/j1/output/W_PM-256_r256_k8.npz", allow_pickle=False) as z:
        expected = z["W|dev6|0"]
    exposure = "E7 dev6 case 0"
else:
    desc = h.Family(3, "val64").T
    expected = np.load(base / "expected3d_W.npy", allow_pickle=False)
    exposure = "refinement val64 case 0 seed 923801"
u0, nu = ic(desc, 0)
out = invoke(u0, nu, burn_seconds=1.0)
measured = out["saved_coefficients"]
assert measured.shape == expected.shape == (6, 256 if dim == 2 else 512)
difference = float(np.max(np.abs(measured - expected)) / np.max(np.abs(expected)))
target = 1e-9
assert out["fields"].shape == ((6,257,257) if dim==2 else (6,63**3))
data = dict(subject=name, cohort=exposure, gpu=jax.devices()[0].device_kind,
            jax_backend=jax.default_backend(),x64=jax.config.jax_enable_x64,
            matmul_precision=os.environ["JAX_DEFAULT_MATMUL_PRECISION"],
            job=os.environ["SLURM_JOB_ID"], seconds=out["seconds"], stopping_reasons=out["reasons"].tolist(),
            expected_coefficients_sha=hashlib.sha256(expected.tobytes()).hexdigest(),
            evaluated_coefficients_sha=hashlib.sha256(measured.tobytes()).hexdigest(),
            rel_max=difference, threshold=target, passed=out["finite"] and difference <= target)
Path("result.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(data),flush=True)
assert data["passed"]
