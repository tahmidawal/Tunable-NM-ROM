#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --gres=gpu:a100:1
#SBATCH --constraint=a100-80G
#SBATCH --cpus-per-task=6
#SBATCH --mem=96G
#SBATCH --time=00:10:00
set -euo pipefail
PY=/cluster/tufts/paralab/tawal01/ae-research/venv/bin/python
export JAX_ENABLE_X64=1 JAX_DEFAULT_MATMUL_PRECISION=highest
export OPENBLAS_NUM_THREADS=6 OMP_NUM_THREADS=6 PYTHONDONTWRITEBYTECODE=1
export TMPDIR="$PWD/tmp" XDG_CACHE_HOME="$PWD/cache"
export CUDA_CACHE_PATH="$PWD/cache/cuda" JAX_COMPILATION_CACHE_DIR="$PWD/cache/jax"
mkdir -p "$TMPDIR" "$CUDA_CACHE_PATH" "$JAX_COMPILATION_CACHE_DIR"
"$PY" -c "import jax,sys; b=jax.default_backend(); print(f'jax_backend={b}',flush=True); sys.exit(0 if b=='gpu' else 42)"
base=/cluster/tufts/paralab/tawal01/jcp-pod-certifier-review-20261115
(cd "$base" && sha256sum -c INPUTS.sha256 --quiet)
nvidia-smi --query-gpu=name,uuid,memory.total --format=csv,noheader
"$PY" "$base/pilot-cert.py" "$1"
sha256sum result.json > OUTPUTS.sha256
