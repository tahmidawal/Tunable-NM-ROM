"""Synthetic-only archived-vs-regenerated cohort identity tests. No archive paths or keys."""
import contextlib
import hashlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import numpy as np

from published import Opened

TEMPLATE = """
import hashlib
import numpy as np

def descriptors_2d(cohort, seed):
    return np.tile(np.array([.2, .3, .4, .5, .11]), (128, 1))

def table_3d(cohort, seed):
    n = 64
    rows = dict(B=np.ones(n, dtype='int64'), c=np.full((n, 3, 3), .4),
                w=np.full((n, 3), .5), rho=np.full((n, 3), .6),
                A=np.full(n, 1.), nu=np.full(n, .11), s_star=np.full(n, 1.57), m=n)
    rows['sha256'] = hashlib.sha256(b''.join(rows[k].tobytes()
        for k in ('B', 'c', 'w', 'rho', 'A', 'nu', 's_star'))).hexdigest()
    return rows
"""


class OriginalDescriptors:
    viscosity = np.nextafter(.11, np.inf)
    peak = 1.57 + 1e-13
    count = 1
    corrupt_space_meta = False
    corrupt_2d_hash = False

    def seed(self, dim):
        return 0

    def meta(self, dim, cohort, index, kind):
        if dim == 2:
            keys = ('cx', 'cy', 'w', 'a', 'nu')
            values = [.2, .3, .4, .5, self.viscosity]
            desc = dict(zip(keys, values))
            cohort_hash = hashlib.sha256(np.tile(np.asarray(values), (128, 1)).tobytes()).hexdigest()
            if self.corrupt_2d_hash:
                cohort_hash = '0' * 64
        else:
            desc = dict(nu=self.viscosity, A=1., s_star=self.peak, B=self.count,
                        c=[[.4, .4, .4]], w=[.5], rho=[.6])
            rows = (np.ones(64, dtype='int64'), np.full((64, 3, 3), .4),
                    np.full((64, 3), .5), np.full((64, 3), .6), np.ones(64),
                    np.full(64, self.viscosity), np.full(64, self.peak))
            cohort_hash = hashlib.sha256(b''.join(a.tobytes() for a in rows)).hexdigest()
        if self.corrupt_space_meta and kind == 'S' and index == 1:
            desc['nu'] = .129
        return dict(desc=desc, cohort_sha256=cohort_hash)


class DescriptorTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        (root / 'jcp-references').mkdir()
        (root / 'jcp-references' / 'cohorts.py').write_text(TEMPLATE)
        self.solver = SimpleNamespace(V=root)
        self.archived = OriginalDescriptors()

    def regenerate(self, dim):
        with contextlib.redirect_stdout(io.StringIO()):
            return Opened.regenerated(self.archived, dim, self.solver)

    def test_portable_ulp_uses_archived_coordinates_and_separate_digests(self):
        for dim in (2, 3):
            with self.subTest(dim=dim):
                rows = self.regenerate(dim)
                receipt = self.archived.descriptor_receipt
                self.assertGreater(receipt['max_relative_draw_difference'], 0)
                self.assertLess(receipt['max_relative_draw_difference'], 1e-14)
                if dim == 3:
                    self.assertGreater(receipt['max_relative_peak_difference'], 0)
                    self.assertLess(receipt['max_relative_peak_difference'], 1e-12)
                self.assertNotEqual(receipt['regenerated_sha256'], receipt['used_sha256'])
                self.assertEqual(set(receipt['original_cohort_sha256_by_batch'].values()), {receipt['used_sha256']})
                self.assertTrue(np.all((rows[:, 4] if dim == 2 else rows['nu']) == self.archived.viscosity))

    def test_wrong_physical_parameter_rejected(self):
        self.archived.viscosity = .111
        for dim in (2, 3):
            with self.subTest(dim=dim), self.assertRaisesRegex(ValueError, 'portability bounds'):
                self.regenerate(dim)

    def test_wrong_peak_rejected(self):
        self.archived.peak = 1.57001
        with self.assertRaisesRegex(ValueError, 'portability bounds'):
            self.regenerate(3)

    def test_wrong_active_blob_count_rejected(self):
        self.archived.count = 2
        with self.assertRaisesRegex(ValueError, 'blobs mismatch'):
            self.regenerate(3)

    def test_original_status_pairs_agree_on_identity(self):
        self.archived.corrupt_space_meta = True
        for dim in (2, 3):
            with self.subTest(dim=dim), self.assertRaisesRegex(ValueError, 'S/ST identities'):
                self.regenerate(dim)

    def test_wrong_reconstructed_2d_commitment_rejected(self):
        self.archived.corrupt_2d_hash = True
        with self.assertRaisesRegex(ValueError, '2D cohort mismatches'):
            self.regenerate(2)


if __name__ == '__main__':
    unittest.main()
