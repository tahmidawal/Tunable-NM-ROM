#!/usr/bin/env bash
#SBATCH --job-name=jcs_witness_dev
#SBATCH --partition=gpu
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=40G
#SBATCH --time=00:30:00
#SBATCH --chdir=/cluster/tufts/paralab/tawal01/jcp-sealed-pod-pilot-20261115/witness-audit
#SBATCH --output=/cluster/tufts/paralab/tawal01/jcp-sealed-pod-pilot-20261115/witness-audit/%j.out
#SBATCH --error=/cluster/tufts/paralab/tawal01/jcp-sealed-pod-pilot-20261115/witness-audit/%j.err
set -euo pipefail
PY=/cluster/tufts/paralab/tawal01/ae-research/venv/bin/python
export JAX_ENABLE_X64=true JAX_DEFAULT_MATMUL_PRECISION=highest OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
export XDG_CACHE_HOME=$PWD/cache TMPDIR=$PWD/tmp PYTHONDONTWRITEBYTECODE=1
export JCPREF_STORE=/cluster/tufts/paralab/tawal01/jcp-ref/store
mkdir -p "$XDG_CACHE_HOME" "$TMPDIR"
sha256sum -c files.sha256
nvidia-smi --query-gpu=name,uuid --format=csv,noheader
"$PY" -c "import jax,sys; b=jax.default_backend(); print(f'jax_backend={b}'); sys.exit(0 if b=='gpu' else 42)"
root=/cluster/tufts/paralab/tawal01/jcp-sealed-closeout-20261115
for d in 2 3; do
  cfg=pilot-d2m256
  if [[ "$d" == 3 ]]; then cfg=pilot-d3m65; fi
  "$PY" witness_audit.py --base "$root/base/experiments/burgers-quadrature-plateau" --config "$root/pilot$d/experiments/jcp-sealed-closeout/configs/$cfg.json" --output "$root/pilot$d/output" --receipt "dev$d-audit.json"
done
sha256sum dev?-audit.json > RECEIPTS.sha256
