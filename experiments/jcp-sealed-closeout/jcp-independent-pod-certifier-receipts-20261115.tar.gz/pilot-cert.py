"""Development-only comparability witness. The process has no opening code."""
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np

from jcp_frozen_classical_pod import prepare

base = Path(__file__).resolve().parent
dim = int(sys.argv[1])
archive = Path("/cluster/tufts/paralab/tawal01/burgers-archive")
assets = {
    2: archive / "imp-multimesh/j0/output/src256",
    3: archive / "jcp-hr-baselines/t3d64b/jobdir/output/artifacts/Phi.npz",
}
sources = Path("/cluster/tufts/paralab/tawal01/jcp-sealed-closeout-20261115/pod-source")
for path, (_, _, _, expected_sha) in json.loads((base/"pod-source.json").read_bytes()).items():
    with (sources/path).open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == expected_sha, path
name, ic, invoke = prepare(dim, Path("/cluster/tufts/paralab/tawal01/jcp-sealed-closeout-20261115/pod-source/experiments"), assets[dim])
import hrcore as h
import jax

if dim == 2:
    desc = h.Family(2, "dev6").D
    with np.load(archive / "imp-multimesh/j1/output/W_PM-256_r256_k8.npz", allow_pickle=False) as z:
        expected = z["W|dev6|0"]
    exposure = "E7 dev6 case 0"
else:
    desc = h.Family(3, "val64").T
    expected = np.load(base / "expected3d_W.npy", allow_pickle=False)
    exposure = "refinement val64 case 0 seed 923801"
u0, nu = ic(desc, 0)
out = invoke(u0, nu, burn_seconds=1.0)
measured = out["saved_coefficients"]
assert measured.shape == expected.shape == (6, 256 if dim == 2 else 512)
difference = float(np.max(np.abs(measured - expected)) / np.max(np.abs(expected)))
target = 1e-9
assert out["fields"].shape == ((6,257,257) if dim==2 else (6,63**3))
data = dict(subject=name, cohort=exposure, gpu=jax.devices()[0].device_kind,
            jax_backend=jax.default_backend(),x64=jax.config.jax_enable_x64,
            matmul_precision=os.environ["JAX_DEFAULT_MATMUL_PRECISION"],
            job=os.environ["SLURM_JOB_ID"], seconds=out["seconds"], stopping_reasons=out["reasons"].tolist(),
            expected_coefficients_sha=hashlib.sha256(expected.tobytes()).hexdigest(),
            evaluated_coefficients_sha=hashlib.sha256(measured.tobytes()).hexdigest(),
            rel_max=difference, threshold=target, passed=out["finite"] and difference <= target)
qualification = out["qualification"]
expected_q = json.loads((base / "frozen-development-expectations.json").read_bytes())["two" if dim==2 else "three"]
discrete_keys = ("valid", "nonstat", "steps", "it_sum") if dim==2 else ("valid", "nonstat", "steps", "it_sum", "damping_saturated", "reason_list", "C_finite", "roundoff_stalls", "reasons")
comparison = {k: qualification[k] == expected_q[k] for k in discrete_keys}
data["certificate_matches"] = comparison
data["qualification"] = qualification
data["certificate_array_valid"] = (len(qualification["gamma_list"]) == len(qualification["reason_list"]) == qualification["steps"] and all(np.isfinite(qualification["gamma_list"])) and qualification["reason_list"] == out["reasons"].tolist() and np.isfinite(qualification["worst_gamma"]) and max(qualification["gamma_list"]) == qualification["worst_gamma"])
if dim == 3:
    data["historical_gamma_max_abs_delta"] = float(np.max(np.abs(np.asarray(expected_q["gamma_list"]) - np.asarray(qualification["gamma_list"]))))
data["passed"] = bool(data["passed"] and all(comparison.values()) and data["certificate_array_valid"])
Path("result.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps(data),flush=True)
assert data["passed"]
