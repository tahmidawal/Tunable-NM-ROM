# Fixed-obstacle Navier–Stokes: staged campaign design

Status: prospective draft dated 2026-10-27, before numerical runs. Independent Codex and
Claude design reviews are required before production. This specification records planned
constants, not measured results. Each release has a frozen source/configuration hash.

## 1. Question, inherited evidence, and hypotheses

Can a reusable ordered coordinate-network velocity bank, geometry-aware off-mesh weak
integration, and a stable pressure treatment solve fixed-obstacle incompressible flow
accurately at useful total query cost? The first target is steady solutions, not transient
trajectories or turbulence. An admissible failure is an intended scientific outcome.

The completed Burgers campaign, improvement campaign (especially geometry E2, hrcost E6,
continuous POD E7), and final 3D refinement all preclude assuming competitive advantage.
The historical spectral geometry crossover estimates are scenarios, not obstacle-flow
measurements. Periodic NS2D vorticity and NS3D curl/Leray/co-moving solvers are algorithms to
inspect, not validated obstacle references. The frozen main heat rollout is not a reference.
The current experimental fork is `93f399faa`, code-only mirror parent `5a64899fd`.

- H-ref: curved body-fitted mixed FE references meet independently tested spatial,
  nonlinear, mass, boundary, force, outlet and domain checks.
- H-rep: ordered bank prefixes improve held-out weighted velocity approximation, with
  pressure/force/derivative error reported separately. No monotonicity is assumed.
- H-int: positive geometry quadrature approaches the full mapped-element reduced weak
  operator and its Jacobian on both fitted and reached states.
- H-query: admitted bank settings meet target output accuracy at lower total query cost
  than the fastest admitted FOM and POD settings. Failure is recorded without replacement
  by an over-solved comparator.
- H-output: fixed-operator/fixed-output work is insensitive to reconstruction mesh size;
  full-field output cost is measured separately and is expected to grow.

## 2. PDE, pressure, stress and dimensions

In the fluid region, with fixed stationary solid boundaries,
$$\partial_t\boldsymbol u+(\boldsymbol u\cdot\nabla)\boldsymbol u
=-\nabla p+\nu\Delta\boldsymbol u,\qquad\nabla\cdot\boldsymbol u=0.$$
Density is constant and set to $\rho=1$. The stored pressure is kinematic pressure
$p=p_{\rm physical}/\rho$. For reproducibility, every output stores dimensional scales:
$x=D\hat x$, $u=U\hat u$, $t=(D/U)\hat t$, $p=U^2\hat p$; hence
$\mathrm{Re}=UD/\nu$. The 2D benchmark is computed in its published dimensional units;
the 3D case uses $D=U=1$. Reduced residual scaling uses these fixed scales, never a
candidate-dependent or viscosity-dependent reweighting.

The benchmark uses the gradient-form outlet condition
$$t_g=(\nu\nabla\boldsymbol u-pI)\boldsymbol n=0.$$
This fixes the pressure level: no extra mean-zero or pinned-pressure constraint is imposed.
It is NOT zero symmetric physical traction. The physical stress per density is
$$\sigma=-pI+\nu(\nabla\boldsymbol u+\nabla\boldsymbol u^T).$$
Force on the obstacle is $F=\rho\int_{\partial B}\sigma n_B\,ds$ with $n_B$ pointing
from solid into fluid (opposite the fluid outward normal). Both physical symmetric stress
and published gradient-stress force are stored; they agree at an exact smooth stationary
no-slip incompressible surface, but their finite-discretization difference is a diagnostic.
A reaction/weak force and independently integrated surface force are also compared.

For momentum and energy checks include inlet/outlet flux and traction. In particular,
$$\frac{d}{dt}\frac12\int_\Omega |u|^2
+2\nu\int_\Omega\epsilon(u):\epsilon(u)
=\int_{\partial\Omega}u\cdot\sigma n
-\frac12\int_{\partial\Omega}|u|^2u\cdot n,$$
for the incompressible continuum problem, with $\epsilon=(\nabla u+\nabla u^T)/2$.
Under $t_g=0$, the physical outlet traction is generally $\nu\nabla u^Tn$, and is counted.
Finite divergence contributions are saved rather than silently interpreted as dissipation.
No unforced periodic-box energy-decay criterion applies.

## 3. Fixed geometries and parameter populations

### 3.1 Established 2D benchmark and first steady family

DFG/Schäfer–Turek 2D-1 specification: rectangle $[0,2.2]\times[0,0.41]$ excluding the
circle of radius $0.05$ centered at $(0.2,0.2)$. No-slip on circle and horizontal walls.
Inlet $u_x=4U_{\max}y(H-y)/H^2$, $u_y=0$, $U_{\max}=0.3$,
$U=U_{\rm mean}=0.2$. Outlet $t_g=0$ at $x=2.2$. Cylinder diameter $D=0.1$;
linear blockage $D/H$, not projected-area blockage. Published benchmark uses $\nu=0.001$
and $\mathrm{Re}=20$. Published drag/lift normalization is $2F/(\rho U^2D)$ per unit span.
Pressure drop is evaluated at exact boundary points $(0.15,0.2)$ and $(0.25,0.2)$.

Primary source: https://wwwold.mathematik.tu-dortmund.de/~featflow/en/benchmarks/cfdbenchmarking/flow/dfg_benchmark1_re20.html
Original provenance: Schäfer and Turek (1996), *Benchmark computations of laminar flow
around a cylinder*, NNFM 52, 547–566; the hosted high-accuracy stationary values are
attributed there to Nabh (1998). Save source values machine-readably, not manually in results.

First family varies viscosity only: $\nu=0.02/\mathrm{Re}$, fixed inlet and geometry.
Training Reynolds numbers: $15+1.25j$, $j=0,\ldots,8$; development: $16.875,23.125$;
validation: $16,18,22,24$. These are disjoint fixed design populations. Mesh seed 27102026;
learning seed 27102027; quadrature seed 27102028 (deterministic rules when possible).
Validation is opened only after architectures, rules, stopping policies and budgets freeze.
No existing sealed/OOD cohort is read. These tiny populations support pilot conclusions only.

The first cost contract is a converged steady query. Newton starts from the fixed-inlet
Stokes lift; its reusable setup and any per-query work are separately charged. There is no
physical time horizon or inlet ramp for a stationary solve; the sole output is the converged
state. A stationary computation is not evidence of a validated transient pipeline.

Domain checks hold the obstacle and local mesh resolution fixed: extend inlet to $x=-0.2$
with the same parabolic inlet data, and separately outlet to $x=4.4$. Compare on the common
original domain. The canonical DFG geometry remains the literature benchmark even if its
upstream length sensitivity fails; do not relabel an extended geometry as DFG. A failed
length-adequacy gate blocks an isolated/length-independent wake claim and must be resolved
before the associated production family is admitted.

### 3.2 Project-defined 3D confined sphere

Candidate geometry: sphere diameter $D=1$ centered at the origin inside a circular pipe
radius $2.5$, axial coordinate $x\in[-5,15]$. Inlet profile
$u_x=2U(1-(y^2+z^2)/2.5^2)$, $u_y=u_z=0$, with cross-sectional mean $U=1$.
No-slip pipe wall and sphere; outlet $t_g=0$, no extra pressure gauge. Linear blockage
$D/(2R)=0.2$, projected-area blockage $D^2/(2R)^2=0.04$; both stored.
Pilot $\mathrm{Re}=10$, $\nu=0.1$; conditional family $\mathrm{Re}=8,10,12$ for training,
$9$ for development, $11$ for validation. Three training states constrain interpretation:
only ranks supported by numerical data rank are eligible, and this is not a broad family.
Force coefficients use $2F/(\rho U^2 A)$, $A=\pi D^2/4$, for axial and both transverse forces.
Pressure probes are at the sphere poles $(-0.5,0,0),(0.5,0,0)$.

This is a new project-defined case, not a reproduced published benchmark. Yin and Ong,
*Physics of Fluids* 32, 103605 (2020), DOI https://doi.org/10.1063/5.0017349, study the
same class of confined stationary-sphere flow but use different Reynolds conventions and
regimes; their transition observations are not transferred to this pilot.
Barber and Emerson, Daresbury report DL-TR-01-001 (2001), continuum no-slip rows only,
https://epubs.stfc.ac.uk/manifestation/255/dltr-2001001.pdf, supply a separate low-Re control.
Their radius-based Reynolds number must be doubled for our diameter convention. The
finite source geometry and source outlet assumptions must be matched before a numerical
agreement claim. No slip-flow table is evidence for a no-slip calculation.

Check $[-10,15]$ and $[-5,30]$ separately, comparing local wake/forces and common-domain
fields with adequate pressure-drop interpretation. Empty-pipe Poiseuille is an exact
geometry/viscosity/outlet control. Full three-component 3D solves are required; symmetry
and optional axisymmetric controls do not substitute for them.

After stationary admission, short transient verification starts from zero with smooth
inlet ramp $a(t)=\sin^2(\pi t/(2t_r))$ for $0\le t<t_r=1$, then unity; $T=2$ in $D/U$
units, saved every $0.1$. BDF2 with a separately checked startup and initial steps
$0.04,0.02,0.01$; these are design settings, not a claim of resolved unsteady wake. Starting
zero with a ramp is a verification case, not the stationary timing baseline.

## 4. Reference method and data gates

Preferred implementation: Netgen curved body-fitted mesh and NGSolve mixed continuous
Taylor–Hood velocity/pressure $P_3/P_2$, with $P_4/P_3$ cross-check. Retain geometry order,
quadrature order, free/Dirichlet DOF maps, exact boundary labels and all Newton histories.
Do not copy the teaching cylinder example's shortened channel or force normalization.
A robust damped Newton solver with independent residual recomputation is the stationary
baseline; compare tuned coarser meshes and polynomial orders, not only finest truth cost.
Sparse direct solves are a small-pilot control; large 3D work is stopped before memory
blowup and requires a reviewed scalable solver/resource amendment.

Dependencies are absent initially. Narrow pinned binary wheel installation into a lane-local
`deps/` target with `--no-deps` and the designated cluster Python is allowed after the design
review; never alter shared JAX or introduce another Python environment. Record wheel hashes,
versions, dependency license/source URLs and a full import check. Preliminary available
candidate versions: ngsolve/netgen-mesher 6.2.2608, netgen-occt 7.8.1, ngsolve-openblas
0.3.33; exact compatibility is a preflight gate, not assumed.

Reference gates (all before training snapshots):

| Check | Prospective admission rule |
|---|---|
| geometry | correct volume/surface labels, no obstacle quadrature; volume and circle/sphere area relative error ≤1e−5 on finest geometry |
| analytic control | empty channel/pipe velocity and pressure relative L2 errors ≤1e−6 with correct outlet; zero no-slip trace to algebraic tolerance |
| steady residual | independent free-DOF scaled residual ≤1e−9; no accepted iteration-limit exit |
| tolerance adequacy | tightening algebraic tolerances by 100 changes u relative L2 ≤1e−5, p ≤2e−5 and each force coefficient ≤1e−5 absolute |
| mass | |Qout−Qin|/Qin ≤1e−7 (2D), ≤1e−6 (3D) |
| divergence | D||div u||L2/(U sqrt(volume)) ≤1e−3 and decreases under refinement; weak constraint residual saved separately |
| boundary | essential velocity trace max/U ≤1e−10; obstacle geometric approximation error reported separately |
| spatial | two successive h refinements and a p cross-check; finest common-field u difference ≤1e−3, p ≤2e−3, drag relative ≤2e−3, transverse coefficient absolute ≤1e−4 (2D) or ≤2e−4 (3D) |
| force integration | refined surface versus weak reaction drag difference ≤2e−3 relative and transverse ≤1e−4 absolute; repeat surface rule at higher order |
| DFG source agreement | drag and pressure-drop relative difference ≤2e−3; lift coefficient absolute difference ≤1e−4 |
| domain/outlet | extensions change local u ≤2e−3, drag ≤2e−3 relative, transverse coefficient ≤2e−4 absolute; separately audit outlet flux/backflow and stress convention |
| balance | stationary momentum and physical energy imbalance ≤5e−3 of sum of absolute individual flux/traction/dissipation contributions (not their near-zero net) |
| transient (separate release) | time refinement at fixed admitted mesh; u gap ≤2e−3, force gaps ≤3e−3 relative for drag or ≤2e−4 absolute transverse; empirical order 1.5–2.5 only when differences exceed solver/noise floor |

Use physical-volume weighted common quadrature for all fields, never nearest nodes at
pressure probes. Pressure is compared in the same outlet-fixed convention, not fitted shifts.
Three-grid convergence and p/control disagreement produce a labelled uncertainty estimate,
not a rigorous error bound. If errors do not decrease or leave asymptotic behavior unresolved,
the case is ineligible for ranking. If source force agreement alone passes, no field-reference
certificate follows. A lower cost/looser reference cannot be admitted by relaxing these bars.
One bounded mesh-level extension may be proposed and audited before viewing its result;
no repeated refinement beyond the resource ceiling.

## 5. Reduced architecture, pressure stability and POD controls

Initial model is a frozen ordered linear learned velocity bank with solved coefficients,
not a nonlinear head. It learns the admitted steady training snapshots only.
$$u(x)=u_L(x)+\sum_{i=1}^r a_i\,b(x)f_i(x;\theta)
+\sum_{j=1}^{p_r}s_j\,v^{\rm sup}_j(x),\qquad
p(x)=p_L(x;\nu)+\sum_{j=1}^{p_r}c_j\psi_j(x).$$
Here $u_L$ is a shared FE Stokes lift for the fixed inlet; its pressure scales with viscosity.
The pressure POD modes and supremizer velocity enrichments are computed using training
only. Rank deficiencies are handled by a fixed numerical-rank rule, reported, not hidden
regularization. The first implementation is a hybrid neural-velocity/FE-lifting-pressure-
supremizer model: it does not establish a fully mesh-free pipeline.

For 2D, the normalized product $b(x,y)=x\,y(H-y)((x-c_x)^2+(y-c_y)^2-a^2)$ vanishes
on inlet, walls and circle, but not outlet. This proves zero correction trace only; it does
not prove divergence-free flow. Coordinates/factors are nondimensionalized to avoid arbitrary
scale conditioning. The 3D counterpart uses inlet distance, pipe radial factor and sphere
signed squared-distance; poles/derivatives require separate checks.

First prefixes $r=2,4,8$, pressure count $p_r=\min(r,\text{training pressure numerical rank})$,
one supremizer per pressure mode; unknown count $d=r+2p_r$. At maximum $d=24$, fixed tests
are 64 momentum vector modes and 16 scalar continuity modes (80 rows). FE smooth modes
and the entire maximum-r supremizer set form common tests. Constant-pressure/flux control
is retained; no sine-box test substitution. Numerical test rank and nonzero outlet flux
ability must be verified. Residual is the steady momentum weak form plus tested divergence,
whitened with fixed nondimensional H1/L2 test Riesz matrices, and minimized by damped
Gauss–Newton/QR. This is **weak-residual least squares**, not Galerkin or full nodal
residual minimization. $M>d$ throughout. No pressure penalty is added to conceal instability.

Pressure stability gate: whitened divergence inf-sup singular value ≥1e−3 and at least
half its full-velocity/same-pressure supremizer reference. Steady Jacobian condition number
≤1e10 after fixed whitening; independent finite-difference Jacobian relative agreement
≤1e−6 at nondegenerate directions. Both norm definitions and any rank trimming are frozen
before case evaluation. Boundary, mass, divergence and pressure errors are separately scored.

POD sees identical training data, weighted inner product, lifting, pressure, supremizers,
output schedule and tuning opportunities. Mandatory controls: unsampled full mapped weak
operator, and exact precontracted quadratic operators for the small mixed reduced space.
A square mixed Galerkin control may be included under its correct name; it is not confused
with the overdetermined LS arms. POD gets the same nonlinear stopping policies and any
later time-integration improvement. Fitted-rule failure leaves unsampled/exact POD eligible.
Report optimal weighted projection floors and gradient/pressure/force diagnostics before
attributing solved errors to representation or dynamics. Projection is a descriptive
best-fit geometry diagnostic, not a feasible PDE solution.

## 6. Quadrature admission

First control is mapped positive element Gauss quadrature on actual curved fluid cells,
with separate curved-boundary rules for force and flux. Increase geometry and quadrature
orders independently. A box mask, random collocation or Fibonacci lattice is not a substitute.
Fitted positive rules use decoder-output snapshots/moments from training only, never residual
snapshots. Candidate budgets m=320,640,1280,2560 (M=80); refit for bank/test changes. This
sequence is a pilot design, not a universal m/M scaling law. No fit on validation/reached
validation states; rejection is allowed. Save support, weights, fit/KKT diagnostics and seed.

Compare each candidate to successively refined full mapped rules on training, development,
and then frozen validation reached states: normalized operator error ≤1e−4, Jacobian ≤1e−4;
returned u change ≤2e−4 and p ≤5e−4; drag coefficient change ≤1e−3 relative and transverse
≤1e−4 absolute. Near-zero residuals use a fixed characteristic term norm denominator,
not division by the tiny net residual. Directional Jacobian consistency is distinct from
quadrature-Jacobian accuracy. Boundary-force quadrature is separately refined. A quadrature
pass is not a PDE-solution pass. NNLS convergence failure stops that rule; one predetermined
larger support is allowed within the listed ladder, not an unbounded fit search.

## 7. Accuracy, work and fair timing contracts

Primary steady pilot targets on every validation case: velocity relative weighted L2 ≤1%,
pressure ≤2%, drag relative ≤2%, transverse force coefficient absolute error ≤0.002,
normalized divergence ≤0.005 and relative inlet/outlet flux mismatch ≤0.001. Reference
uncertainty must be smaller than one fifth of the corresponding comparison tolerance,
otherwise matching is unresolved. These are feasibility targets, not a speed-win condition.
Keep medians, maxima, and counts beyond each target; never replace worst cases with means.

Three separate matched outputs: full u/p fields on common requested points; fixed probes;
integrated forces. Each query saves initialization, coefficient solve/evolution, output
reconstruction, total time, nonlinear iterations, Jacobian evaluations and peak memory.
Offline costs include data generation, lift/test/basis construction, training, quadrature
fitting, validation qualification and compilation. Report amortized and cold contracts.
Common geometry/offline cached preparation is available to FOM/POD too, including reused
factorizations/preconditioners and previous-query starts only in a declared ordered workload.

Primary timing is paired **same CPU cores in one allocation**: NGSolve FOM and CPU
NumPy reduced algebra/frozen tanh network evaluation, thread counts fixed. GPU training is
offline. Optional GPU reduced timings are heterogeneous-platform diagnostics and cannot
be substituted in same-device speed claims. Cluster GPU allocation/preflight is retained
and allocated GPU-hours count even when FOM kernels execute on CPU. Store both CPU and GPU
hardware identifiers. Run burn-in immediately before each timed block (GPU burn-in before
any GPU block), discard documented compilation/warmup calls, and store seven repetition
arrays with paired alternating method order. Cost and accuracy are outputs of the same
solver invocation; each repetition retains result identity/field checksum and work counts.

FOM ladder: admitted coarse/fine curved mesh and polynomial settings; match to bank accuracy,
not only to reference-data tolerance. Report fastest admitted competitor satisfying ALL
requested outputs/constraints. Speed ratios are conditional on the finite tested ladder.
Break-even uses complete offline cost divided by positive per-query saving; if saving is
nonpositive report no break-even, not a negative query count. No cross-job timing ratio.

## 8. Stages, ceilings, stop rules and releases

Total initial ceiling: 12 allocated GPU-hours, all failures included; 8 reference/infrastructure
and 4 conditional ROM/POD. At most 2 simultaneous jobs, one GPU each, ≤16 CPU cores/job.
First smoke per dimension ≤20 minutes and ≤64 GiB RAM; later memory ceiling 128 GiB only
with reviewed estimate. Unique new local data cap 60 GiB, remote temporary cap 50 GiB.
Jobs use gpu partition, f64 and highest precision, GPU preflight, exclusive directories,
direct paralab staging, source/config hashes, seeded cluster regeneration, and pre/post
squeue checks. Collect/checksum all outputs before deleting remote duplicates. Never delete
unique data or archive worktrees. Do not use bare scancel; avoid cancellation by bounded
wall times unless the repository's explicit-ID guarded cancellation is applicable.

- G0: source specification + dependency plan + independent Codex AND Claude design review.
- G1: code/control review then exact smoke-config review; bounded import/geometry/analytic
  controls; preserve failure. At most one infrastructure repair per distinct ordinary error,
  within resource cap; scientific changes require a dated amendment.
- G2: reference suite with all §4 gates and independent result review. Only admitted data
  can feed training. 2D and 3D reference infrastructure may progress independently.
- G3: 2D small complete steady learned-bank/POD/FOM pilot after G2; predeclare architecture
  and training steps based on available snapshot dimensions. No broad hyperparameter search.
  If representation/pressure/force/divergence gates fail, preserve result and stop expansion.
- G4: 3D representation/memory estimate and tiny steady/transient pilot only after 3D G2
  and 2D G3, without large bank training. If estimated allocation/data exceeds remaining
  cap, defer explicitly; do not use the total cap as permission for larger sweeps.
- G5: unsteady 2D uses DFG 2D-2 at Re100, its published domain and outlet, with primary
  source https://wwwold.mathematik.tu-dortmund.de/~featflow/en/benchmarks/cfdbenchmarking/flow/dfg_benchmark2_re100.html .
  Its documented periodic regime motivates the case, not an assumed transition threshold.
  Requires a separate prospective release defining ramp, transient discard, horizon, dt,
  training population, reference force/frequency ranges and total budget BEFORE execution.
  Phase-sensitive trajectory error remains primary; aligned diagnostics are supplemental.
- G6: bounded one-factor width/test/quadrature/output-mesh/policy sweeps only for admitted
  pilot endpoints within remaining cap. Unsteady 3D requires separate verified regime and
  resource release and is not automatically authorized by a smooth steady result.

Scientific blockers stop the dependent stage, not independent documentation/control work.
Claude authentication/usage failure leaves a saved packet and an explicitly missing gate;
do not retry indefinitely or call that review passed. Reviews target realistic equations,
execution and interpretation, not invented adversarial file scenarios. Each amendment
preserves original criterion, original result, reason, timestamp and scope.

## 9. Evidence, report and handoff

Save job ledger, exact scripts/configs, source hashes, dependency manifests, mesh/geometry
metadata, raw fields/coefficients, timing repetitions, solver traces, gates and reviewer
responses. Generate tables/plots from JSON/NPZ with provenance; no hand-transcribed measured
number enters the report. Reports live on main when published; implementation remains on
separate unmerged experiment branches. Preserve original presentation bytes/order when adding
pages. Final handoff lists completed, failed, deferred and open items, retention locations,
resource usage and outstanding merge decision. Ask the user whether to merge after lanes
finish; do not merge unprompted. Canonical LAB-LOG update records outcomes/retractions.

## Glossary

FOM: full spatially resolved PDE solver. ROM: reduced model solving few coefficients.
POD: weighted snapshot singular-vector basis. Bank: frozen learned spatial functions;
r: number of selected learned velocity columns; p: pressure-mode count; d: all online
unknowns; M: weak test row count; m: fluid integration point count; N: requested output
mesh resolution. Lifting: fixed field carrying nonzero boundary values. Supremizer:
velocity enrichment paired to a pressure mode to stabilize pressure coupling. Inf-sup:
smallest scaled velocity-pressure coupling, not a solution-accuracy certificate. Weak
residual: PDE tested against smooth functions after integration by parts. Quadrature:
weighted numerical integration. Reference: independently checked numerical approximation,
not exact truth. No-slip: zero fluid velocity on a stationary solid surface. Kinematic
pressure: physical pressure divided by density. Traction: force per area on a surface.
Blockage: stated obstacle-to-pipe width or area ratio. Reached state: a solution actually
returned by the reduced solve. Gate: prospective acceptance rule. Query: all work needed
to return the declared output. Offline: reusable preparation, still charged in break-even.

## A1 — Pre-data clarification after independent Codex design review, 2026-10-27

No numerical run has occurred. This amendment resolves draft ambiguity; the original draft
is preserved at commit b0cd5eddc. No failed threshold is relaxed.

**Release boundaries.** G2-steady covers geometry, analytic plus manufactured nonzero-
convection controls, stationary tolerances, space, forces, balances and domain/outlet checks.
G2-transient is a separate unpassed gate. G3 needs G2-steady only. A full three-component
manufactured divergence-free velocity with nonzero convection and nonconstant pressure,
consistent source and exact nonzero natural outlet traction is required for 3D code admission;
2D has the analogous mixed control. Control forcing/traction are never used in the physical
unforced obstacle case. Derivatives are independently checked symbolically or by AD.

**Time alignment.** The proposed 3D transient ladder is replaced before execution by
$\Delta t=0.05,0.025,0.0125$, all dividing output spacing $0.1$ and ramp time $1$.
Use fixed-step BDF2 after an independently checked second-order startup, not unverified
shortened steps or interpolation. This does not release the transient stage.

**Field metrics.** On the declared common physical-volume rule $Q$, define
$\|f\|_Q^2=\sum w_i|f_i|^2$ and $V_Q=\sum w_i$. Velocity error is
$\|u-u_{ref}\|_Q/\max(\|u_{ref}\|_Q,10^{-12}U\sqrt{V_Q})$.
Primary pressure error is characteristic-scaled RMS,
$\|p-p_{ref}\|_Q/(U^2\sqrt{V_Q})$, in the unshifted outlet convention. All pressure
thresholds in §§4,6,7 use that convention. Reference-relative pressure error is retained as
an explicitly secondary diagnostic. For domain extension compare pressure *differences*
across the same physical probes, since outlet-fixed absolute levels include the added pipe
pressure loss. Relative drag error divides by $|C_{D,ref}|$; transverse forces use absolute
coefficient error. Report raw norms, denominators and coefficients with every derived metric.

**Algebra and reduced metrics.** Before first execution the reference code must serialize
its free-DOF residual normalization (including fixed velocity/pressure units and initial
Stokes residual floor), linear residual criterion, damping and maximum iterations in the
exact reviewed configuration; the physical output tightening gate cannot be replaced by
that algebraic value. Reduced tests use reference-geometry dimensionless H1 velocity Gram
$G_v=\int(v_i\cdot v_j+\nabla v_i:\nabla v_j)$ and L2 pressure Gram
$G_q=\int q_iq_j$, Cholesky-whitened once and fixed across Reynolds number, quadrature,
iteration and mesh-output sweeps. Whiten unknown coordinates by full-rule physical velocity
L2 and pressure L2 Gram matrices when computing Jacobian conditioning and inf-sup values.
Exact rank cutoff is $10^{-12}$ times largest singular value; if the retained dimension
changes, store original/retained counts and apply the same rule to both methods.

Quadrature operator and Jacobian gaps use the Euclidean/Frobenius norm of whitened vectors/
matrices, divided by the sum of corresponding full-rule separate viscous, advective,
pressure/lifting and continuity term norms, with floor $10^{-12}$. Never divide by their
nearly canceled total. Save numerator and denominator. Derivative checks use centered
finite differences at step sizes $10^{-4},10^{-5},10^{-6}$ in whitened coefficient directions,
require an interior error plateau or reduction and best relative error ≤1e−6; no claimed
Jacobian accuracy when the finite-difference signal lies below roundoff.

**Uncertainty and matching.** After decreasing three-level h differences and an independent
p cross-check, use conditional estimate
$\delta_y=2\max(d_{y,h_{fine}},d_{y,p})+d_{y,solver}+d_{y,quad}$ in the declared output metric.
Store every constituent and reject unresolved/nondecreasing spatial behavior. This is not
a rigorous bound. Reference uncertainty must fit the one-fifth comparison budget in §7.
For matching, form conditional error interval $[\max(0,e-\delta),e+\delta]$ for each output;
a competitor jointly matches only if its upper interval is no larger than the bank lower
interval for every primary output, with all physics gates passed. Matching a common target
is reported separately from a resolved error dominance claim. If zero-error floors prevent
resolved ordering, report unresolved rather than force a winner.

**Geometry/envelopes.** FE Dirichlet trace tolerance applies on that FE geometry; neural
analytic zero trace applies on the exact geometry. Record exact-to-FE boundary distances,
volume/surface errors and the neural correction trace sampled on both boundaries. Before
ROM training, define and review the geometry evaluation map, require approximate-boundary
trace discrepancy/U ≤1e−6 for eligible reconstructed fields, and verify its contribution
under geometry-order refinement. This is a separate geometry consistency gate, not a
relaxation of the exact essential trace criterion. If it fails, defer the continuous bank
until an exact geometry map or a qualified consistent representation exists. In 3D the
inlet factor is always $(x-x_{in})/(x_{out}-x_{in})$.

**Scope and comparators.** Central 3D domain $[-5,15]$ and its separately prescribed
extensions supersede the discovery suggestion $[-10,20]$ before data. Full-3D comparisons
are labelled as the tested three-component solver ladder; no best-possible sphere-FOM
claim without a qualified axisymmetric comparator if symmetry holds. Give both bank and
POD exact quadratic tensor evaluation, alongside unsampled quadrature and fitted positive
rules; tensor precomputation/storage/reconstruction are charged consistently.

**Outlet sensitivity.** In addition to length controls, run a named alternative symmetric-
physical-traction-zero outlet on the longer domain. It is a different boundary model, not
the DFG definition. The same common-local-field and force tolerances apply; pressure drop
is compared on common probes. Failure limits domain/outlet independence and blocks generic
wake/force-reference use; finite-domain DFG source comparison remains separately labelled.

## A2 — Physical balance and finite-domain scope clarification, 2026-10-27

Still before numerical runs. The second independent Codex review confirms core conventions
and adds these release details. The finite-domain DFG numerical-reference gate and domain-
insensitivity gate are recorded separately. A correctly reproduced DFG reference can pass
while the broader wake/force expansion gate fails. This campaign deliberately requires both
before expanding the production family; it does not claim a length-sensitive finite-domain
solution is numerically wrong. If insensitivity fails, the original DFG outcome is retained
and any changed-domain family needs a separately frozen specification.

For the actually discretized advective/gradient weak PDE, save independently evaluated
balances with finite-divergence corrections. Writing $\tau=\nu\nabla u-pI$, stationary
momentum mismatch is
$$B_m=\int_{\partial\Omega}[u(u\cdot n)-\tau n]\,ds
-\int_\Omega u\nabla\cdot u\,dx.$$
The gradient-form energy mismatch is
$$B_e=\nu\int_\Omega|\nabla u|^2
+\frac12\int_{\partial\Omega}|u|^2u\cdot n
-\int_{\partial\Omega}u\cdot\tau n
-\frac12\int_\Omega |u|^2\nabla\cdot u
-\int_\Omega p\nabla\cdot u.$$
Include $dE/dt$ for a transient and body-force work for manufactured controls. Physical
symmetric-stress balance is a separately reported continuum consistency diagnostic, not
quietly substituted for this exact discrete-form accounting. Normalize by sum of absolute
term magnitudes with characteristic force/power floor $10^{-12}$ in nondimensional units.

The low-Re Barber–Emerson drag comparison remains auxiliary: its zero-axial-gradient outlet
is not established identical to ours, and its reported no-slip normal-stress discrepancy
precludes treating the rounded table as exact truth or assigning it our tight reference gate.

## A3 — Independent Claude consultation and implementation release, 2026-10-27

The first larger Claude request timed out without output; one shorter retry returned a
substantive review. Both attempts and all raw reviews are retained. Reviewers permit
implementation of dependency/geometry/analytic controls; this amendment releases that work.
Code and exact-job review are still required for numerical smoke. Reference acceptance and
training remain closed. `reviews/RESPONSE-A3.md` records accepted and qualified suggestions.

Add a manufactured nonzero-Dirichlet, divergence-free flow with nonzero convection on the
actual obstacle geometry, not only an empty box. Prescribe its consistent forcing and
nonzero outlet pseudotraction; check analytic curved-surface force. Pair weak reaction with
gradient-form direct force. The physical-minus-gradient force gap must be ≤2e−4 relative
in drag and ≤1e−5 absolute transverse at admitted finest references; it is one physical
force with two discrete evaluations. An exact-sign wall-shear control precedes a DFG claim.
Primary geometry orders are3 for P3/P2 and4 for P4/P3, plus an independent geometry-order
increase holding solution order fixed. Mass remains an algebra/quadrature check, not a
certificate of spatial divergence error.

The first 3D factorization cannot be released until the reviewed 2D smoke succeeds and
its code has a prospective small-system guard: at most15000 mixed unknowns, conservative
estimated factorization storage $128d_h^2+4\,\mathrm{GiB}\le48\,\mathrm{GiB}$ under a64GiB
hard limit, and an element-count guard before assembly. This estimate is not a mathematical
memory guarantee; actual peak RSS and failure logs must be saved. Geometry/mesh-only checks
may precede factorization. Measure the first two coarse levels before projecting larger
levels; full reference failure at affordable resolution is recorded as unresolved. No new
iterative solver or larger memory allocation is silently substituted.

Use velocity H1 and pressure L2 norms for the reduced inf-sup matrix:
$\beta=\sigma_{\min}(G_p^{-1/2}BG_{v,H1}^{-1/2})$, with correctly oriented Cholesky factors
or symmetric inverse roots. This supersedes A1's loose inclusion of inf-sup in velocity-L2
unknown whitening. The Jacobian condition diagnostic may retain its explicitly fixed
velocity-L2/pressure-L2 coefficient scaling. All actual Gram definitions are stored.

Mandatory additional competitors: standard exact mixed POD-Galerkin with supremizers, and
piecewise cubic Hermite interpolation of training POD coefficients in Reynolds number,
using a fixed training-only weighted basis and no PDE solve. It gets identical lifting,
pressure/forces and physics/accuracy checks; its negligible solve cost is not hidden by an
irrelevant algebraic residual gate. Fields/outputs and constitutive PDE residual diagnostics
still identify any inaccurate interpolated result. No validation data tune the interpolator.
The present family and validation set support interpolation-only conclusions.

Before bank reduced online solves, freeze and evaluate representation floors on development:
velocity≤0.002 and characteristic-scaled pressure≤0.004. Failure stops the bank expansion;
POD/FOM/interpolation controls still proceed. Save gradient, force and trace errors too;
passing velocity projection alone cannot certify a force model. Width ordering is weighted
QR/SVD after the one fixed two-hidden-layer64-unit tanh fit (seed27102027,max3000steps,
first training wall cap30min); input coordinates are nondimensionalized by D, then affinely
scaled using fixed geometry bounds. No architecture or seed search follows a failed fit.

Actual momentum/continuity test enumeration and fitted moment definitions must be explicit
and independently reviewed in code before training. Both tensors and fitted rules are
available to bank and POD. Empirical-order/roundoff diagnostics and per-population reference
checks must be frozen in the reference-suite configuration; no acceptance from decreasing
but unresolved noise. Every eventual train/dev/validation case needs admitted references,
not just the Re20 anchor. The snapshot-generation contract prevents method-selection access
to validation field values until the model choices freeze.

## A4 — Pressure-space and deterministic test construction, 2026-10-27

Before fitting or numerical reference jobs, specify pressure basis as constant first, then
weighted POD of training pressures after removing their weighted means. Thus
$p_r=\min(r,1+\operatorname{rank}(P_{train,centered}))$; the raw-snapshot rank shorthand in
§5 is superseded. No zero-mean constraint is imposed on the reconstructed pressure: the
constant is an actual solved mode, coupled through outlet-free velocity tests. This same
rule applies to bank/POD/interpolation. Total unknown cap remains $r+2p_r\le24$.

Construct the fixed momentum tests by first including all maximum-prefix pressure
supremizers, then geometry-compatible vector H1 eigenmodes in increasing eigenvalue order.
Essential trace is zero and outlet trace remains free. Construct continuity tests from the
constant, all pressure modes, then scalar Laplacian modes. Weighted orthogonalization drops
linearly dependent candidates at relative cutoff $10^{-12}$ until the fixed64/16 sizes are
reached; failure to achieve them blocks that setting. Freeze eigensolver, deterministic
orientation/tie convention and retained candidate indices in exported metadata. The code
review must check the actual enumeration, not assume stability from the labels.


## Implementation amendment A5 — private native-library layout, 2026-10-27

The first bounded G1 allocation failed before FE execution: the pinned OCCT wheel's native
libraries were absent after pip `--target` installation. All wheel hashes and JAX GPU/f64
preflight passed; the retained ledger and failure archive record the actual attempt.
One ordinary repair for this distinct infrastructure error installs the same pinned wheels
with `--no-deps --no-index --ignore-installed --prefix` into a fresh job-owned directory.
The designated interpreter is unchanged. Only that job's `PYTHONPATH` and native-library
search path point to its prefix; no new interpreter environment or shared-package mutation
is permitted. Verify native RECORD files, package import and post-import GPU/f64 before FE
controls. Exact source/config review and fresh checksummed staging precede the single retry.
All physics, scientific acceptance criteria, populations and resource ceilings are unchanged.
The original target-install outcome is retained; no flow result existed to reinterpret.

## Amendment A6 — stable FE basis construction before data, 2026-10-27

No reference snapshot, FE-adapter execution or training result has been admitted. Independent
Claude review of the adapter and Codex adjudication found a known vector-eigenvalue
multiplicity gap and a conditioning risk in coefficient transport through division by small
singular values. The original source, conservative rejection checks and synthetic failures
remain preserved. Earlier narrow source readiness is superseded for adapter execution.
Neither inevitable failure at a particular singular ratio nor a fixed component ratio for
all vector eigenmodes is claimed. Physical acceptance criteria and scientific rank cutoffs
remain unchanged.

**POD construction.** For each field, form training FE coefficient columns $C$ and the
assembled full-rule mass metric $M$. Use deterministic pivoted mass-metric Gram–Schmidt
with reorthogonalization, retaining the permutation in $C\Pi=QR$. An SVD of the small
factor, $R=U_R\Sigma V_R^T$, gives coefficient modes $QU_R$. Avoid transport through
$CV/\sigma$. QR pivoting is not an additional scientific rank rule: the original independent
sampled-SVD rank references/cutoffs determine the required modes; inability to construct
those modes is a hard failure, with no accuracy-tolerance-based column dropping.
Pressure QR uses spatially centered pressure corrections, retains the original uncentered
rank reference, and keeps the normalized constant first.
Protect that known normalized constant as an orthogonalization direction during both
pressure CGS2 passes, before normalization or the small SVD. This maintains the intended
centered subspace in finite precision; retain the backward-error check against the original
centered coefficient matrix. It is not a pressure-gauge change, extra rank cutoff or repair
of failed output modes. The initial synthetic constant-contamination rejection is preserved.

The fixed consistency scales are $S_v=\sigma_{v,1}$ for nonzero velocity corrections and
$S_p=\max(1,\sigma_{p,1}^{\rm uncentered})$ for pressure. Zero velocity corrections have no
eligible registered velocity prefix and stop that construction. Zero centered pressure
returns only the constant and does not divide by its zero leading singular value. With
these scales, the following numerical checks must pass before modes are used:

- QR backward error $\|C\Pi-QR\|_{M,F}/S\le10^{-10}$, with the actual permutation saved.
- Metric orthonormality and actual sampled-mode Gram spectral error at most $10^{-10}$.
- Maximum absolute difference between sampled and small-factor singular values, divided
  by $S$, at most $10^{-10}$; retain the original sampled rank selection and sufficient
  QR directions for every required retained mode.
- At every registered available prefix, each training case's weighted residual norm agrees
  with the residual of the independent sampled-SVD prefix to $10^{-10}S$. These are
  per-case consistency comparisons; POD optimality concerns aggregate weighted squared
  error, not a separate optimal basis for each case. Also save aggregate projection floors.

POD cluster tests use the full singular spectrum before truncation. Normalize by the
leading nonzero singular value and declare adjacent values clustered when their gap is at
most $\max(64\epsilon_{64},10^{-10}\max(|s_i|,|s_{i+1}|))$. Reject a cut through a detected
cluster at the numerical-rank boundary, retained maximum, or eligible registered prefix;
pressure-tail cut indices are $p_r-1$. No hidden rank reduction selects passing modes.
For QR and coefficient-orientation pivots, the score is the relevant squared residual/row
norm. Scores within $64\epsilon_{64}$ times the maximum nonzero score tie; choose the
smallest frozen snapshot/DOF index. The zero-score case is handled explicitly. This is a
numerical tie convention, not universal cross-platform uniqueness of eigenvectors.

**Velocity test eigenbank.** Solve the scalar H1 eigenproblem at the velocity polynomial
order with the same essential boundary set and free outlet. Retain 48 scalar candidates
plus one look-ahead, then explicitly emit $(\phi_j,0)$ and $(0,\phi_j)$ in that order.
Verify scalar-to-vector DOF maps, matching diagonal blocks and negligible cross blocks;
do not assume a coefficient-array split. Block Frobenius discrepancies normalized by a
nonzero matching diagonal-block norm must be at most $10^{-12}$. Pressure scalar candidate
count remains 32. Keep the fixed final 64 momentum/16 continuity tests and existing
supremizer-first/rank rules. The look-ahead label is `gap_checked`; returned residuals and
gaps do not certify that the scalar solver found every eigenvalue. This construction
resolves the known component duplication, not every possible scalar multiplicity.

**Independent geometry and interface controls.** Add the nonsymmetric affine velocity
$u=(y,0)$ (cyclic $u=(y,z,x)$ in 3D), checking full volume and wrapped boundary gradients
against the explicit analytic matrix at the existing gradient tolerance. On an actual
curved mesh, use an auxiliary fixture degree sufficient to represent its coordinate map;
production spaces are unchanged. Check reloaded normals against analytic side/radial
orientation and normalized normal closure on the obstacle and the union of outer faces,
not on an individual open inlet/outlet face. Closure alone does not establish sign.
The normal-closure tolerance is $10^{-10}$ times the corresponding boundary measure.

Every adapter export explicitly declares already-dimensionless coordinates, weights,
velocities, pressures, lifts and derivatives. Consumers must not apply the physical-to-
dimensionless conversion again. A future producer may export one validated shared Stokes
velocity lift and pressure coefficient per viscosity on the immutable common mesh. Reuse
and pressure scaling are allowed in the tuned FOM query too; one-time construction is
counted offline for both methods. Vectorized FE evaluation remains an implementation
optimization requiring ordering/memory/ownership checks, not an assumed measured gain.

The independent policy review permits implementation of A6. Exact source review, admitted
G2 producer data, curved reload evidence and bounded native runtime controls are still
required. These checks can reject ill-conditioned inputs; no universal success is promised.
