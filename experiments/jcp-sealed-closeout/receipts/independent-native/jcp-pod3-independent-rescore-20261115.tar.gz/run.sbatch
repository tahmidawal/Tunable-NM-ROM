#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --gres=gpu:l40s:1
#SBATCH --cpus-per-task=2
#SBATCH --mem=6G
#SBATCH --time=00:05:00
set -euo pipefail
umask 077
dim=$1
test "$dim" = 2 || test "$dim" = 3
prefix=/cluster/tufts/paralab/tawal01/jcp-open-pod-witness-20261115
cold=/cluster/tufts/paralab/tawal01/burgers-archive/jcp-sealed-closeout-20261115/pod$dim
export JAX_ENABLE_X64=true JAX_DEFAULT_MATMUL_PRECISION=highest JAX_PLATFORMS=cuda
export TMPDIR="$PWD/tmp" XDG_CACHE_HOME="$PWD/cache" PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export JCP_OPEN_REGISTRY=/cluster/tufts/paralab/tawal01/jcp-opening-records/3ec3b5492748a162c9d77e7c09cdbe1485d449a31bd73a29175b4a0e4efc66a0
export JCP_APPROVED_REVIEW_SHA256=898f19eb1c1c0753656121f6a7d0b4ac70a77f44f539718234abf8631bf9652c
mkdir -p "$TMPDIR" "$XDG_CACHE_HOME"
(cd "$prefix" && sha256sum -c SOURCE.sha256 --quiet)
(cd "$cold" && sha256sum -c ARCHIVE.sha256 --quiet && sha256sum -c OUTPUTS.sha256 --quiet && sha256sum -c SOURCE.sha256 --quiet)
PY=/cluster/tufts/paralab/tawal01/ae-research/venv/bin/python
"$PY" -c "import jax,sys; b=jax.default_backend(); print(f'jax_backend={b}'); sys.exit(0 if b=='gpu' and jax.config.jax_enable_x64 and str(jax.config.jax_default_matmul_precision)=='highest' else 42)"
nvidia-smi --query-gpu=name,uuid --format=csv,noheader
"$PY" "$prefix/rescore.py" "$dim"
sha256sum receipt.json > OUTPUTS.sha256
